C_coe=[3,4,5,6,7];
hold off
L2err=[1.637e-3, 5.4561e-4, 9.1107e-5, 3.4453e-4, 5.3954e-4];
plot(C_coe, L2err,'-ro','LineWidth',1.5);

hold on
LwqErr= [2.8174e-3, 1.0728e-3, 2.8501e-4, 7.7855e-4, 1.0892e-3];
plot(C_coe, LwqErr,'-bv','LineWidth',1.5);
Lrms=[2.5892e-3 8.5946e-4 1.4351e-4 5.4272e-4 8.4991e-4];
plot(C_coe, Lrms,'-kx','LineWidth',1.5);
ylabel ('Errors')
xlabel('c^2')
legend('L^2', 'L^\infty', 'RMS')